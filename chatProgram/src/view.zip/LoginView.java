/*
 * 로그인 화면 뷰
 */

package chat.view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginView extends JPanel {

	JPanel loginPan = new JPanel(new GridLayout(3, 2, 10, 10));
	JButton btnLogin = new JButton("로그인");
	
	
	public LoginView() {
		setLayout(new BorderLayout(10, 10));
		
		//로그인 패널에 추가할 컴포넌트들
		JLabel lblTitle = new JLabel("로 그 인");
		lblTitle.setHorizontalAlignment(JLabel.CENTER);
		lblTitle.setFont(new Font("", Font.BOLD, 15));
		
		JLabel lblId = new JLabel("아이디 : ");
		JLabel lblPw = new JLabel("비밀번호 : ");
		JLabel lblBlank = new JLabel("");
		lblId.setHorizontalAlignment(JLabel.RIGHT);
		lblPw.setHorizontalAlignment(JLabel.RIGHT);
		
		JTextField tfId = new JTextField();
		JPasswordField tfPw = new JPasswordField();
		
		//패널에 컴포넌트 추가
		loginPan.add(lblId); loginPan.add(tfId);
		loginPan.add(lblPw); loginPan.add(tfPw);
		loginPan.add(lblBlank); loginPan.add(btnLogin);
		
		add("North", lblTitle);
		add("Center", loginPan);
	}
	
	
	//다른 클래스에서 btnLogin 버튼에 접근 가능하게 함
	public JButton getBtnLogin() {
		return btnLogin;
	}

	
}
